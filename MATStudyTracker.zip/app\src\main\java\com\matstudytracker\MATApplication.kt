package com.matstudytracker

import android.app.Application
import com.matstudytracker.data.database.AppDatabase
import com.matstudytracker.data.repository.StudyRepository

class MATApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy {
        StudyRepository(
            database.studyRecordDao(),
            database.studyPlanDao(),
            database.syllabusProgressDao()
        )
    }
}
