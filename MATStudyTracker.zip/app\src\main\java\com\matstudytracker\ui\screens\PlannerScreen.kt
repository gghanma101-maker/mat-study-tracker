package com.matstudytracker.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matstudytracker.data.SyllabusData
import com.matstudytracker.data.model.StudyPlan
import com.matstudytracker.viewmodel.PlannerViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(viewModel: PlannerViewModel) {
    val plans by viewModel.allPlans.collectAsStateWithLifecycle()
    val completedCount by viewModel.completedCount.collectAsStateWithLifecycle()
    val totalCount by viewModel.totalCount.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("পড়াশোনার পরিকল্পনা", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("আপনার স্টাডি প্ল্যান তৈরি ও পরিচালনা করুন", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Stats
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Card(
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalCount", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                            Text("মোট পরিকল্পনা", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF4CAF50).copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$completedCount", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                color = Color(0xFF4CAF50))
                            Text("সম্পন্ন", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFF9800).copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${totalCount - completedCount}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF9800))
                            Text("বাকি আছে", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            if (plans.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Filled.EventNote, contentDescription = null,
                                modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("কোনো পরিকল্পনা নেই", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("নতুন স্টাডি প্ল্যান যোগ করতে + বাটনে ক্লিক করুন", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            items(plans, key = { it.id }) { plan ->
                PlanCard(plan = plan, onToggle = { viewModel.toggleComplete(plan) }, onDelete = { viewModel.deletePlan(plan) })
            }
        }

        // FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 100.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            shape = CircleShape
        ) {
            Icon(Icons.Filled.Add, contentDescription = "পরিকল্পনা যোগ করুন", tint = MaterialTheme.colorScheme.onPrimary)
        }
    }

    if (showAddDialog) {
        AddPlanDialog(onDismiss = { showAddDialog = false }, onAdd = { plan -> viewModel.addPlan(plan); showAddDialog = false })
    }
}

@Composable
private fun PlanCard(plan: StudyPlan, onToggle: () -> Unit, onDelete: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale("bn")) }
    val priorityColor = when (plan.priority) { 1 -> Color(0xFFE53935); 2 -> Color(0xFFFFA726); else -> Color(0xFF66BB6A) }
    val priorityText = when (plan.priority) { 1 -> "উচ্চ"; 2 -> "মাঝারি"; else -> "নিম্ন" }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (plan.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (plan.isCompleted) 0.dp else 2.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
            Checkbox(
                checked = plan.isCompleted, onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF4CAF50))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    plan.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    textDecoration = if (plan.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (plan.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Subject, contentDescription = null, modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(plan.subject, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${dateFormat.format(Date(plan.scheduledDate))} | ${plan.startTime} - ${plan.endTime}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier.background(priorityColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("অগ্রাধিকার: $priorityText", style = MaterialTheme.typography.labelSmall, color = priorityColor)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddPlanDialog(onDismiss: () -> Unit, onAdd: (StudyPlan) -> Unit) {
    var title by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf(SyllabusData.subjects[0]) }
    var topic by remember { mutableStateOf("") }
    var priority by remember { mutableIntStateOf(2) }
    var subjectExpanded by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val calendar = remember { Calendar.getInstance() }
    var selectedDate by remember { mutableLongStateOf(calendar.timeInMillis) }
    var startTime by remember { mutableStateOf("09:00") }
    var endTime by remember { mutableStateOf("10:00") }
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale("bn")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন পরিকল্পনা", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    OutlinedTextField(
                        value = title, onValueChange = { title = it },
                        label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp), singleLine = true
                    )
                }
                item {
                    ExposedDropdownMenuBox(expanded = subjectExpanded, onExpandedChange = { subjectExpanded = it }) {
                        OutlinedTextField(
                            value = selectedSubject, onValueChange = {},
                            label = { Text("বিষয়") }, readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(expanded = subjectExpanded, onDismissRequest = { subjectExpanded = false }) {
                            SyllabusData.subjects.forEach { subject ->
                                DropdownMenuItem(text = { Text(subject) }, onClick = { selectedSubject = subject; subjectExpanded = false })
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = topic, onValueChange = { topic = it },
                        label = { Text("টপিক") }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp), singleLine = true
                    )
                }
                item {
                    OutlinedButton(
                        onClick = {
                            DatePickerDialog(context, { _, y, m, d ->
                                calendar.set(y, m, d); selectedDate = calendar.timeInMillis
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                        },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.CalendarToday, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("তারিখ: ${dateFormat.format(Date(selectedDate))}")
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(context, { _, h, m -> startTime = String.format("%02d:%02d", h, m) },
                                    9, 0, true).show()
                            },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                        ) { Text("শুরু: $startTime") }
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(context, { _, h, m -> endTime = String.format("%02d:%02d", h, m) },
                                    10, 0, true).show()
                            },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                        ) { Text("শেষ: $endTime") }
                    }
                }
                item {
                    Text("অগ্রাধিকার", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "উচ্চ", 2 to "মাঝারি", 3 to "নিম্ন").forEach { (p, label) ->
                            FilterChip(
                                selected = priority == p, onClick = { priority = p },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = when (p) { 1 -> Color(0xFFE53935); 2 -> Color(0xFFFFA726); else -> Color(0xFF66BB6A) }.copy(alpha = 0.2f)
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAdd(StudyPlan(title = title, subject = selectedSubject, topic = topic,
                            scheduledDate = selectedDate, startTime = startTime, endTime = endTime, priority = priority))
                    }
                },
                shape = RoundedCornerShape(12.dp)
            ) { Text("যোগ করুন") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        },
        shape = RoundedCornerShape(24.dp)
    )
}
