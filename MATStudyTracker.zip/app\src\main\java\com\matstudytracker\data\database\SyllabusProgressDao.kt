package com.matstudytracker.data.database

import androidx.room.*
import com.matstudytracker.data.model.CompletedTopic
import kotlinx.coroutines.flow.Flow

@Dao
interface SyllabusProgressDao {
    @Query("SELECT * FROM completed_topics")
    fun getAllCompleted(): Flow<List<CompletedTopic>>

    @Query("SELECT COUNT(*) FROM completed_topics")
    fun getCompletedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markCompleted(topic: CompletedTopic)

    @Delete
    suspend fun markIncomplete(topic: CompletedTopic)

    @Query("SELECT EXISTS(SELECT 1 FROM completed_topics WHERE topicKey = :key)")
    fun isCompleted(key: String): Flow<Boolean>
}
