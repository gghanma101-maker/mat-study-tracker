package com.matstudytracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.matstudytracker.data.model.StudyPlan
import com.matstudytracker.data.repository.StudyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlannerViewModel(private val repository: StudyRepository) : ViewModel() {

    val allPlans: StateFlow<List<StudyPlan>> = repository.allPlans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedCount: StateFlow<Int> = repository.completedPlanCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalCount: StateFlow<Int> = repository.totalPlanCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addPlan(plan: StudyPlan) {
        viewModelScope.launch {
            repository.insertPlan(plan)
        }
    }

    fun deletePlan(plan: StudyPlan) {
        viewModelScope.launch {
            repository.deletePlan(plan)
        }
    }

    fun toggleComplete(plan: StudyPlan) {
        viewModelScope.launch {
            repository.togglePlanComplete(plan.id, !plan.isCompleted)
        }
    }

    class Factory(private val repository: StudyRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PlannerViewModel(repository) as T
        }
    }
}
