package com.matstudytracker.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matstudytracker.data.SyllabusData
import com.matstudytracker.data.model.SyllabusCategory
import com.matstudytracker.data.model.SyllabusTopic
import com.matstudytracker.ui.theme.*
import com.matstudytracker.viewmodel.SyllabusViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyllabusScreen(viewModel: SyllabusViewModel) {
    val completedTopics by viewModel.completedTopics.collectAsStateWithLifecycle()
    val completedCount by viewModel.completedCount.collectAsStateWithLifecycle()

    val overallProgress = if (viewModel.totalTopics > 0)
        completedCount.toFloat() / viewModel.totalTopics else 0f

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "MAT সিলেবাস",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "বাংলাদেশ ম্যানেজমেন্ট অ্যাডমিশন টেস্ট",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Overall progress
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("সামগ্রিক অগ্রগতি", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("$completedCount/${viewModel.totalTopics}", style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    val animProg by animateFloatAsState(overallProgress, tween(1000), label = "op")
                    LinearProgressIndicator(
                        progress = { animProg },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("${(overallProgress * 100).toInt()}% সম্পন্ন", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Categories
        items(SyllabusData.categories) { category ->
            SyllabusCategoryCard(
                category = category,
                completedTopics = completedTopics,
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun SyllabusCategoryCard(
    category: SyllabusCategory,
    completedTopics: Set<String>,
    viewModel: SyllabusViewModel
) {
    var expanded by remember { mutableStateOf(false) }
    val catColor = Color(category.colorHex)
    val completed = viewModel.getCompletedCountForCategory(category.id, completedTopics)
    val total = viewModel.getTotalCountForCategory(category.id)
    val progress = if (total > 0) completed.toFloat() / total else 0f

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            // Category header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(48.dp).clip(CircleShape)
                        .background(catColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when (category.icon) {
                        "book" -> Icons.Filled.MenuBook
                        "language" -> Icons.Filled.Language
                        "calculate" -> Icons.Filled.Calculate
                        "analytics" -> Icons.Filled.Analytics
                        "psychology" -> Icons.Filled.Psychology
                        "public" -> Icons.Filled.Public
                        else -> Icons.Filled.Book
                    }
                    Icon(icon, contentDescription = null, tint = catColor, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(category.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = catColor,
                            trackColor = catColor.copy(alpha = 0.15f),
                            strokeCap = StrokeCap.Round
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("$completed/$total", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Expanded topics
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    category.topics.forEach { topic ->
                        TopicSection(
                            topic = topic,
                            catColor = catColor,
                            completedTopics = completedTopics,
                            onToggle = { key, isCompleted -> viewModel.toggleTopic(key, isCompleted) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopicSection(
    topic: SyllabusTopic,
    catColor: Color,
    completedTopics: Set<String>,
    onToggle: (String, Boolean) -> Unit
) {
    var topicExpanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { topicExpanded = !topicExpanded }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (topicExpanded) Icons.Filled.FolderOpen else Icons.Filled.Folder,
                contentDescription = null,
                tint = catColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                topic.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            val topicCompleted = topic.subtopics.indices.count { i ->
                completedTopics.contains("${topic.id}_$i")
            }
            Text(
                "$topicCompleted/${topic.subtopics.size}",
                style = MaterialTheme.typography.labelSmall,
                color = catColor
            )
        }

        AnimatedVisibility(
            visible = topicExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(modifier = Modifier.padding(start = 30.dp)) {
                topic.subtopics.forEachIndexed { index, subtopic ->
                    val key = "${topic.id}_$index"
                    val isCompleted = completedTopics.contains(key)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggle(key, isCompleted) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isCompleted,
                            onCheckedChange = { onToggle(key, isCompleted) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = catColor,
                                uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            subtopic,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isCompleted) MaterialTheme.colorScheme.onSurfaceVariant
                            else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
