# MAT Study Tracker (ম্যাট স্টাডি ট্র্যাকার) 📚🇧🇩

বাংলাদেশ ম্যানেজমেন্ট অ্যাডমিশন টেস্ট (MAT / IBA / MBA Admission Test) প্রস্তুতির জন্য একটি আধুনিক ও পরিচ্ছন্ন অ্যান্ড্রয়েড অ্যাপ্লিকেশন। এটি সম্পূর্ণ বাংলা ভাষায় তৈরি এবং আধুনিক **Jetpack Compose**, **Material 3** এবং **Room Database** আর্কিটেকচারে গঠিত।

---

## 🌟 মূল বৈশিষ্ট্যসমূহ (Features)

1. **ড্যাশবোর্ড (Dashboard / হোম):**
   - দৈনন্দিন শুভেচ্ছা এবং প্রেরণা
   - আজকের পড়ার সময় ও মোট অধ্যয়নের ঘণ্টা ট্র্যাকিং
   - সিলেবাস অগ্রগতি সারসংক্ষেপ
   - দ্রুত অ্যাকশন বাটন এবং আসন্ন স্টাডি প্ল্যানের তালিকা

2. **সম্পূর্ণ MAT সিলেবাস ট্র্যাকার (Syllabus Tracker):**
   - বাংলাদেশের MAT / IBA পরীক্ষা উপযোগী ৬টি প্রধান ক্যাটাগরি:
     - 📖 **বাংলা ভাষা ও সাহিত্য** (ব্যাকরণ, সাহিত্য, বাগধারা, শুদ্ধ বানান)
     - 🌐 **ভাষা বোধগম্যতা (ইংরেজি)** (RC, Vocabulary, Grammar, Para Jumbles)
     - 📐 **গাণিতিক দক্ষতা** (পাটিগণিত, বীজগণিত, জ্যামিতি ও পরিমিতি, আধুনিক গণিত)
     - 📊 **তথ্য বিশ্লেষণ ও পর্যাপ্ততা (Data Analysis & Sufficiency)**
     - 🧠 **বুদ্ধিমত্তা ও যুক্তি (Intelligence & Reasoning)**
     - 🌍 **অর্থনৈতিক ও ব্যবসায়িক পরিবেশ (GK & Business Environment)**
   - সাব-টপিক ভিত্তিক চেকলিস্ট ও রিয়েলটাইম পার্সেন্টেজ গণনা

3. **স্টাডি প্ল্যানার (Study Planner):**
   - দৈনিক ও সাপ্তাহিক লক্ষ্য নির্ধারণ
   - বিষয়, টপিক, তারিখ এবং সময়সূচি (Time slot) নির্বাচন
   - অগ্রাধিকার স্তর (উচ্চ, মাঝারি, নিম্ন) নির্ধারণ
   - প্ল্যান সম্পন্ন হলে এক ক্লিকে টিক চিহ্ন ও পরিচালনা

4. **পড়ার রেকর্ড লগ (Study Records Log):**
   - প্রতিটি রিডিং সেশন (কত মিনিট পড়লেন, কোন টপিক, তারিখ ও ব্যক্তিগত নোট) সংরক্ষণ
   - সর্বমোট অধ্যয়ন ঘণ্টার পরিসংখ্যান

5. **অগ্রগতি ও বিশ্লেষণ (Analytics & Progress):**
   - বৃত্তাকার সামগ্রিক পার্সেন্টেজ ইন্ডিকেটর
   - বিষয়ভিত্তিক অগ্রগতি বার
   - MAT পরীক্ষার স্পেশাল টিপস ও স্ট্র্যাটেজি

---

## 🛠️ প্রযুক্তিগত বৈশিষ্ট্য (Tech Stack)

- **Language:** Kotlin 1.9.22
- **UI Toolkit:** Jetpack Compose + Material 3 (Dynamic Color Support)
- **Architecture:** MVVM (Model-View-ViewModel) + Clean Repository Pattern
- **Local Database:** Room Database + Kotlin Coroutines & Flow (Offline-first)
- **Navigation:** Jetpack Navigation Compose with animated transitions
- **Design System:** Material You themed typography, custom curves, Bengali numeral & date formatting

---

## 🚀 কীভাবে চালাবেন (How to Run)

1. আপনার **Android Studio** (Hedgehog বা পরবর্তী সংস্করণ) ওপেন করুন।
2. **Open Project** নির্বাচন করে নিচের ডিরেক্টরিটি সিলেক্ট করুন:
   ```
   C:\Users\User\.gemini\antigravity\scratch\MATStudyTracker
   ```
3. Gradle Sync সম্পন্ন হতে দিন।
4. একটি এমুলেটর (AVD) বা ফিজিক্যাল অ্যান্ড্রয়েড ফোন কানেক্ট করে **Run** (Shift+F10) বাটনে চাপ দিন।
