# Proguard rules for MAT Study Tracker
-keep class com.matstudytracker.data.model.** { *; }
