package com.matstudytracker.data.database

import androidx.room.*
import com.matstudytracker.data.model.StudyPlan
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyPlanDao {
    @Query("SELECT * FROM study_plans ORDER BY scheduledDate ASC, startTime ASC")
    fun getAllPlans(): Flow<List<StudyPlan>>

    @Query("SELECT * FROM study_plans WHERE scheduledDate >= :startOfDay AND scheduledDate < :endOfDay ORDER BY startTime ASC")
    fun getPlansForDay(startOfDay: Long, endOfDay: Long): Flow<List<StudyPlan>>

    @Query("SELECT * FROM study_plans WHERE isCompleted = 0 AND scheduledDate >= :today ORDER BY scheduledDate ASC, startTime ASC LIMIT :limit")
    fun getUpcomingPlans(today: Long, limit: Int = 5): Flow<List<StudyPlan>>

    @Query("SELECT COUNT(*) FROM study_plans WHERE isCompleted = 1")
    fun getCompletedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM study_plans")
    fun getTotalCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(plan: StudyPlan)

    @Delete
    suspend fun delete(plan: StudyPlan)

    @Update
    suspend fun update(plan: StudyPlan)

    @Query("UPDATE study_plans SET isCompleted = :completed WHERE id = :planId")
    suspend fun toggleComplete(planId: Int, completed: Boolean)
}
