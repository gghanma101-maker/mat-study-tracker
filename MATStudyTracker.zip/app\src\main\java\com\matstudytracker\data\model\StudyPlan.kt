package com.matstudytracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_plans")
data class StudyPlan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subject: String,
    val topic: String,
    val scheduledDate: Long,
    val startTime: String,
    val endTime: String,
    val isCompleted: Boolean = false,
    val priority: Int = 2 // 1=উচ্চ, 2=মাঝারি, 3=নিম্ন
)
