package com.matstudytracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.matstudytracker.data.SyllabusData
import com.matstudytracker.data.model.CompletedTopic
import com.matstudytracker.data.repository.StudyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SyllabusViewModel(private val repository: StudyRepository) : ViewModel() {

    val completedTopics: StateFlow<Set<String>> = repository.allCompletedTopics
        .map { list -> list.map { it.topicKey }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val completedCount: StateFlow<Int> = repository.completedTopicCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalTopics: Int = SyllabusData.getTotalTopicCount()

    fun toggleTopic(topicKey: String, isCompleted: Boolean) {
        viewModelScope.launch {
            if (isCompleted) {
                repository.markTopicIncomplete(topicKey)
            } else {
                repository.markTopicCompleted(topicKey)
            }
        }
    }

    fun getCompletedCountForCategory(categoryId: String, completed: Set<String>): Int {
        return completed.count { it.startsWith(categoryId) || 
            SyllabusData.categories.find { c -> c.id == categoryId }
                ?.topics?.any { t -> it.startsWith(t.id) } == true
        }
    }

    fun getTotalCountForCategory(categoryId: String): Int {
        return SyllabusData.categories.find { it.id == categoryId }
            ?.topics?.sumOf { it.subtopics.size } ?: 0
    }

    class Factory(private val repository: StudyRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SyllabusViewModel(repository) as T
        }
    }
}
