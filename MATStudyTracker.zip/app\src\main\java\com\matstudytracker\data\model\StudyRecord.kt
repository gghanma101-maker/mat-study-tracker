package com.matstudytracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_records")
data class StudyRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val topic: String,
    val durationMinutes: Int,
    val date: Long,
    val notes: String = ""
)
