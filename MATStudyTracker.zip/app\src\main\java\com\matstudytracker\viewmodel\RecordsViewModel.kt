package com.matstudytracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.matstudytracker.data.model.StudyRecord
import com.matstudytracker.data.repository.StudyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class RecordsViewModel(private val repository: StudyRepository) : ViewModel() {

    val allRecords: StateFlow<List<StudyRecord>> = repository.allRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalMinutes: StateFlow<Int> = repository.totalMinutes
        .map { it ?: 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addRecord(record: StudyRecord) {
        viewModelScope.launch {
            repository.insertRecord(record)
        }
    }

    fun deleteRecord(record: StudyRecord) {
        viewModelScope.launch {
            repository.deleteRecord(record)
        }
    }

    class Factory(private val repository: StudyRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return RecordsViewModel(repository) as T
        }
    }
}
