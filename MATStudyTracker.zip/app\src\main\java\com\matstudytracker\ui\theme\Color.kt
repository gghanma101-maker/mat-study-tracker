package com.matstudytracker.ui.theme

import androidx.compose.ui.graphics.Color

// Primary - Deep Teal
val PrimaryLight = Color(0xFF006B5E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFF7CF8E0)
val OnPrimaryContainerLight = Color(0xFF00201B)

// Secondary - Warm Amber
val SecondaryLight = Color(0xFF8B5E00)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDEA6)
val OnSecondaryContainerLight = Color(0xFF2C1A00)

// Tertiary - Indigo
val TertiaryLight = Color(0xFF4355B9)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFDEE0FF)
val OnTertiaryContainerLight = Color(0xFF00105C)

// Error
val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

// Background & Surface
val BackgroundLight = Color(0xFFF5FBF7)
val OnBackgroundLight = Color(0xFF171D1B)
val SurfaceLight = Color(0xFFF5FBF7)
val OnSurfaceLight = Color(0xFF171D1B)
val SurfaceVariantLight = Color(0xFFDAE5E0)
val OnSurfaceVariantLight = Color(0xFF3F4945)

// Dark Theme
val PrimaryDark = Color(0xFF5EDBC4)
val OnPrimaryDark = Color(0xFF003830)
val PrimaryContainerDark = Color(0xFF005047)
val OnPrimaryContainerDark = Color(0xFF7CF8E0)

val SecondaryDark = Color(0xFFFFBB3B)
val OnSecondaryDark = Color(0xFF492D00)
val SecondaryContainerDark = Color(0xFF694600)
val OnSecondaryContainerDark = Color(0xFFFFDEA6)

val TertiaryDark = Color(0xFFBAC3FF)
val OnTertiaryDark = Color(0xFF08218A)
val TertiaryContainerDark = Color(0xFF293CA0)
val OnTertiaryContainerDark = Color(0xFFDEE0FF)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF0F1513)
val OnBackgroundDark = Color(0xFFDFE4E0)
val SurfaceDark = Color(0xFF0F1513)
val OnSurfaceDark = Color(0xFFDFE4E0)
val SurfaceVariantDark = Color(0xFF3F4945)
val OnSurfaceVariantDark = Color(0xFFBEC9C4)

// Subject Colors
val SubjectBangla = Color(0xFF4CAF50)
val SubjectEnglish = Color(0xFF2196F3)
val SubjectMath = Color(0xFFFF9800)
val SubjectAnalytical = Color(0xFF9C27B0)
val SubjectGK = Color(0xFFE91E63)
val SubjectData = Color(0xFF00BCD4)
