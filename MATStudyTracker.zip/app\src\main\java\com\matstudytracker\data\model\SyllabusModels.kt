package com.matstudytracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "completed_topics")
data class CompletedTopic(
    @PrimaryKey val topicKey: String
)

data class SyllabusCategory(
    val id: String,
    val name: String,
    val icon: String,
    val colorHex: Long,
    val topics: List<SyllabusTopic>
)

data class SyllabusTopic(
    val id: String,
    val name: String,
    val subtopics: List<String>
)
