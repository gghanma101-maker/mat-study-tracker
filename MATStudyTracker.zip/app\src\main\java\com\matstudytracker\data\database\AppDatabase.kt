package com.matstudytracker.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.matstudytracker.data.model.CompletedTopic
import com.matstudytracker.data.model.StudyPlan
import com.matstudytracker.data.model.StudyRecord

@Database(
    entities = [StudyRecord::class, StudyPlan::class, CompletedTopic::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studyRecordDao(): StudyRecordDao
    abstract fun studyPlanDao(): StudyPlanDao
    abstract fun syllabusProgressDao(): SyllabusProgressDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mat_study_tracker_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
