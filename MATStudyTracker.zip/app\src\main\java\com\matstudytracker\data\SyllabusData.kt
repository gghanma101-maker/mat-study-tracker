package com.matstudytracker.data

import com.matstudytracker.data.model.SyllabusCategory
import com.matstudytracker.data.model.SyllabusTopic

object SyllabusData {

    val subjects = listOf(
        "বাংলা ভাষা ও সাহিত্য",
        "ভাষা বোধগম্যতা (ইংরেজি)",
        "গাণিতিক দক্ষতা",
        "তথ্য বিশ্লেষণ ও পর্যাপ্ততা",
        "বুদ্ধিমত্তা ও যুক্তি",
        "অর্থনৈতিক ও ব্যবসায়িক পরিবেশ"
    )

    val categories = listOf(
        SyllabusCategory(
            id = "bangla",
            name = "বাংলা ভাষা ও সাহিত্য",
            icon = "book",
            colorHex = 0xFF4CAF50,
            topics = listOf(
                SyllabusTopic(
                    id = "bangla_grammar",
                    name = "বাংলা ব্যাকরণ",
                    subtopics = listOf(
                        "ধ্বনি ও বর্ণ",
                        "শব্দ প্রকরণ",
                        "সন্ধি বিচ্ছেদ",
                        "সমাস",
                        "প্রত্যয়",
                        "উপসর্গ",
                        "কারক ও বিভক্তি",
                        "বাক্য প্রকরণ",
                        "বাচ্য পরিবর্তন",
                        "বচন"
                    )
                ),
                SyllabusTopic(
                    id = "bangla_literature",
                    name = "বাংলা সাহিত্য",
                    subtopics = listOf(
                        "প্রাচীন ও মধ্যযুগ",
                        "আধুনিক যুগ",
                        "রবীন্দ্রনাথ ঠাকুর",
                        "কাজী নজরুল ইসলাম",
                        "মুক্তিযুদ্ধভিত্তিক সাহিত্য",
                        "বিখ্যাত কবি ও লেখক"
                    )
                ),
                SyllabusTopic(
                    id = "bangla_idioms",
                    name = "বাগধারা ও প্রবাদ",
                    subtopics = listOf(
                        "বাগধারা",
                        "প্রবাদ-প্রবচন",
                        "এককথায় প্রকাশ",
                        "বিপরীত শব্দ",
                        "সমার্থক শব্দ"
                    )
                ),
                SyllabusTopic(
                    id = "bangla_spelling",
                    name = "বানান ও শব্দ",
                    subtopics = listOf(
                        "শুদ্ধ বানান",
                        "পারিভাষিক শব্দ",
                        "দেশি-বিদেশি শব্দ",
                        "শব্দের অর্থভেদ"
                    )
                )
            )
        ),

        SyllabusCategory(
            id = "english",
            name = "ভাষা বোধগম্যতা (ইংরেজি)",
            icon = "language",
            colorHex = 0xFF2196F3,
            topics = listOf(
                SyllabusTopic(
                    id = "english_rc",
                    name = "রিডিং কম্প্রিহেনশন",
                    subtopics = listOf(
                        "Passage-based Questions",
                        "Main Idea & Theme",
                        "Inference Questions",
                        "Tone & Attitude",
                        "Vocabulary in Context"
                    )
                ),
                SyllabusTopic(
                    id = "english_vocab",
                    name = "শব্দভাণ্ডার",
                    subtopics = listOf(
                        "Synonyms & Antonyms",
                        "Idioms & Phrases",
                        "One-word Substitution",
                        "Foreign Words",
                        "Analogies"
                    )
                ),
                SyllabusTopic(
                    id = "english_grammar",
                    name = "ইংরেজি ব্যাকরণ",
                    subtopics = listOf(
                        "Sentence Correction",
                        "Error Spotting",
                        "Fill in the Blanks",
                        "Parts of Speech",
                        "Tense & Voice",
                        "Subject-Verb Agreement",
                        "Articles & Prepositions"
                    )
                ),
                SyllabusTopic(
                    id = "english_arrangement",
                    name = "বাক্য সাজানো",
                    subtopics = listOf(
                        "Para Jumbles",
                        "Sentence Rearrangement",
                        "Odd Sentence Out",
                        "Paragraph Completion"
                    )
                )
            )
        ),

        SyllabusCategory(
            id = "math",
            name = "গাণিতিক দক্ষতা",
            icon = "calculate",
            colorHex = 0xFFFF9800,
            topics = listOf(
                SyllabusTopic(
                    id = "math_arithmetic",
                    name = "পাটিগণিত",
                    subtopics = listOf(
                        "শতকরা",
                        "লাভ-ক্ষতি",
                        "সুদকষা (সরল ও চক্রবৃদ্ধি)",
                        "অনুপাত ও সমানুপাত",
                        "গড়",
                        "সময় ও কাজ",
                        "সময়, দূরত্ব ও গতি",
                        "মিশ্রণ"
                    )
                ),
                SyllabusTopic(
                    id = "math_algebra",
                    name = "বীজগণিত",
                    subtopics = listOf(
                        "সরলীকরণ",
                        "একঘাত ও দ্বিঘাত সমীকরণ",
                        "অসমতা",
                        "লগারিদম",
                        "সমান্তর ও গুণোত্তর ধারা",
                        "সূচক ও করণী"
                    )
                ),
                SyllabusTopic(
                    id = "math_geometry",
                    name = "জ্যামিতি ও পরিমিতি",
                    subtopics = listOf(
                        "রেখা ও কোণ",
                        "ত্রিভুজ",
                        "বৃত্ত",
                        "চতুর্ভুজ ও বহুভুজ",
                        "ক্ষেত্রফল",
                        "আয়তন ও পৃষ্ঠতল"
                    )
                ),
                SyllabusTopic(
                    id = "math_modern",
                    name = "আধুনিক গণিত",
                    subtopics = listOf(
                        "বিন্যাস ও সমাবেশ",
                        "সম্ভাব্যতা",
                        "সেট তত্ত্ব",
                        "সংখ্যা পদ্ধতি",
                        "বিভাজ্যতা"
                    )
                )
            )
        ),

        SyllabusCategory(
            id = "data",
            name = "তথ্য বিশ্লেষণ ও পর্যাপ্ততা",
            icon = "analytics",
            colorHex = 0xFF00BCD4,
            topics = listOf(
                SyllabusTopic(
                    id = "data_tables",
                    name = "সারণি ও কেসলেট",
                    subtopics = listOf(
                        "সারণি বিশ্লেষণ",
                        "কেসলেট ভিত্তিক প্রশ্ন",
                        "তথ্য থেকে সিদ্ধান্ত"
                    )
                ),
                SyllabusTopic(
                    id = "data_charts",
                    name = "গ্রাফ ও চার্ট",
                    subtopics = listOf(
                        "বার চার্ট",
                        "পাই চার্ট",
                        "লাইন গ্রাফ",
                        "মিশ্র গ্রাফ"
                    )
                ),
                SyllabusTopic(
                    id = "data_sufficiency",
                    name = "তথ্য পর্যাপ্ততা",
                    subtopics = listOf(
                        "একটি বিবৃতি পর্যাপ্ত",
                        "উভয় বিবৃতি প্রয়োজন",
                        "কোনটিই যথেষ্ট নয়",
                        "তথ্য পর্যাপ্ততার কৌশল"
                    )
                ),
                SyllabusTopic(
                    id = "data_venn",
                    name = "ভেন ডায়াগ্রাম",
                    subtopics = listOf(
                        "দুই সেটের ভেন ডায়াগ্রাম",
                        "তিন সেটের ভেন ডায়াগ্রাম",
                        "ম্যাক্সিমা-মিনিমা সমস্যা"
                    )
                )
            )
        ),

        SyllabusCategory(
            id = "reasoning",
            name = "বুদ্ধিমত্তা ও যুক্তি",
            icon = "psychology",
            colorHex = 0xFF9C27B0,
            topics = listOf(
                SyllabusTopic(
                    id = "reasoning_verbal",
                    name = "মৌখিক যুক্তি",
                    subtopics = listOf(
                        "যুক্তিবাক্য (Syllogisms)",
                        "বিবৃতি ও অনুমান",
                        "বিবৃতি ও সিদ্ধান্ত",
                        "কারণ ও ফলাফল",
                        "দাবি ও যুক্তি"
                    )
                ),
                SyllabusTopic(
                    id = "reasoning_analytical",
                    name = "বিশ্লেষণাত্মক যুক্তি",
                    subtopics = listOf(
                        "কোডিং-ডিকোডিং",
                        "সংখ্যা ও বর্ণ ধারা",
                        "ধাঁধা",
                        "ঘড়ি ও ক্যালেন্ডার",
                        "ঘনক ও পাশা"
                    )
                ),
                SyllabusTopic(
                    id = "reasoning_relations",
                    name = "সম্পর্ক ও দিক",
                    subtopics = listOf(
                        "রক্তসম্পর্ক",
                        "দিক নির্ণয়",
                        "ক্রম ও র‍্যাঙ্কিং",
                        "দূরত্ব ও অবস্থান"
                    )
                ),
                SyllabusTopic(
                    id = "reasoning_seating",
                    name = "বসার ব্যবস্থা",
                    subtopics = listOf(
                        "সরলরেখায় বসার ব্যবস্থা",
                        "বৃত্তাকার বসার ব্যবস্থা",
                        "জটিল ব্যবস্থা",
                        "ফ্লোর ভিত্তিক ব্যবস্থা"
                    )
                )
            )
        ),

        SyllabusCategory(
            id = "gk",
            name = "অর্থনৈতিক ও ব্যবসায়িক পরিবেশ",
            icon = "public",
            colorHex = 0xFFE91E63,
            topics = listOf(
                SyllabusTopic(
                    id = "gk_current",
                    name = "সাম্প্রতিক বিষয়াবলি",
                    subtopics = listOf(
                        "জাতীয় সংবাদ",
                        "আন্তর্জাতিক সংবাদ",
                        "ব্যবসায়িক সংবাদ",
                        "বাংলাদেশ সম্পর্কিত"
                    )
                ),
                SyllabusTopic(
                    id = "gk_economy",
                    name = "অর্থনীতি ও ব্যবসা",
                    subtopics = listOf(
                        "মৌলিক অর্থনৈতিক ধারণা",
                        "শেয়ার বাজার",
                        "ব্যাংকিং ও অর্থায়ন",
                        "আন্তর্জাতিক বাণিজ্য",
                        "বাংলাদেশের অর্থনীতি"
                    )
                ),
                SyllabusTopic(
                    id = "gk_awards",
                    name = "পুরস্কার ও সম্মাননা",
                    subtopics = listOf(
                        "নোবেল পুরস্কার",
                        "জাতীয় পুরস্কার",
                        "আন্তর্জাতিক পুরস্কার",
                        "বিখ্যাত ব্যক্তিত্ব"
                    )
                ),
                SyllabusTopic(
                    id = "gk_orgs",
                    name = "সংস্থা ও সদর দপ্তর",
                    subtopics = listOf(
                        "জাতিসংঘ ও অঙ্গসংস্থা",
                        "আঞ্চলিক সংস্থা",
                        "আর্থিক সংস্থা",
                        "বাংলাদেশি সংস্থা"
                    )
                )
            )
        )
    )

    fun getTotalTopicCount(): Int {
        return categories.sumOf { category ->
            category.topics.sumOf { it.subtopics.size }
        }
    }

    fun getAllTopicKeys(): List<String> {
        val keys = mutableListOf<String>()
        categories.forEach { category ->
            category.topics.forEach { topic ->
                topic.subtopics.forEachIndexed { index, _ ->
                    keys.add("${topic.id}_$index")
                }
            }
        }
        return keys
    }
}
