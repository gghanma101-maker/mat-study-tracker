package com.matstudytracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.matstudytracker.data.SyllabusData
import com.matstudytracker.data.model.StudyPlan
import com.matstudytracker.data.model.StudyRecord
import com.matstudytracker.data.repository.StudyRepository
import kotlinx.coroutines.flow.*
import java.util.Calendar

class DashboardViewModel(private val repository: StudyRepository) : ViewModel() {

    private val calendar = Calendar.getInstance()
    private val startOfDay: Long
        get() {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            return cal.timeInMillis
        }
    private val endOfDay: Long
        get() = startOfDay + 24 * 60 * 60 * 1000

    val totalMinutes: StateFlow<Int> = repository.totalMinutes
        .map { it ?: 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todayMinutes: StateFlow<Int> = repository.getTodayMinutes(startOfDay, endOfDay)
        .map { it ?: 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val completedTopics: StateFlow<Int> = repository.completedTopicCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalTopics: Int = SyllabusData.getTotalTopicCount()

    val upcomingPlans: StateFlow<List<StudyPlan>> = repository.getUpcomingPlans(startOfDay, 5)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentRecords: StateFlow<List<StudyRecord>> = repository.allRecords
        .map { it.take(5) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recordCount: StateFlow<Int> = repository.recordCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    class Factory(private val repository: StudyRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(repository) as T
        }
    }
}
