package com.matstudytracker.data.repository

import com.matstudytracker.data.database.StudyPlanDao
import com.matstudytracker.data.database.StudyRecordDao
import com.matstudytracker.data.database.SyllabusProgressDao
import com.matstudytracker.data.model.CompletedTopic
import com.matstudytracker.data.model.StudyPlan
import com.matstudytracker.data.model.StudyRecord
import kotlinx.coroutines.flow.Flow

class StudyRepository(
    private val recordDao: StudyRecordDao,
    private val planDao: StudyPlanDao,
    private val syllabusDao: SyllabusProgressDao
) {
    // Study Records
    val allRecords: Flow<List<StudyRecord>> = recordDao.getAllRecords()
    val totalMinutes: Flow<Int?> = recordDao.getTotalMinutes()
    val recordCount: Flow<Int> = recordDao.getRecordCount()

    fun getRecordsForDay(startOfDay: Long, endOfDay: Long): Flow<List<StudyRecord>> =
        recordDao.getRecordsForDay(startOfDay, endOfDay)

    fun getTodayMinutes(startOfDay: Long, endOfDay: Long): Flow<Int?> =
        recordDao.getTodayMinutes(startOfDay, endOfDay)

    fun getMinutesBySubject(subject: String): Flow<Int?> =
        recordDao.getMinutesBySubject(subject)

    suspend fun insertRecord(record: StudyRecord) = recordDao.insert(record)
    suspend fun deleteRecord(record: StudyRecord) = recordDao.delete(record)

    // Study Plans
    val allPlans: Flow<List<StudyPlan>> = planDao.getAllPlans()
    val completedPlanCount: Flow<Int> = planDao.getCompletedCount()
    val totalPlanCount: Flow<Int> = planDao.getTotalCount()

    fun getUpcomingPlans(today: Long, limit: Int = 5): Flow<List<StudyPlan>> =
        planDao.getUpcomingPlans(today, limit)

    fun getPlansForDay(startOfDay: Long, endOfDay: Long): Flow<List<StudyPlan>> =
        planDao.getPlansForDay(startOfDay, endOfDay)

    suspend fun insertPlan(plan: StudyPlan) = planDao.insert(plan)
    suspend fun deletePlan(plan: StudyPlan) = planDao.delete(plan)
    suspend fun updatePlan(plan: StudyPlan) = planDao.update(plan)
    suspend fun togglePlanComplete(planId: Int, completed: Boolean) =
        planDao.toggleComplete(planId, completed)

    // Syllabus Progress
    val allCompletedTopics: Flow<List<CompletedTopic>> = syllabusDao.getAllCompleted()
    val completedTopicCount: Flow<Int> = syllabusDao.getCompletedCount()

    fun isTopicCompleted(key: String): Flow<Boolean> = syllabusDao.isCompleted(key)

    suspend fun markTopicCompleted(key: String) =
        syllabusDao.markCompleted(CompletedTopic(key))

    suspend fun markTopicIncomplete(key: String) =
        syllabusDao.markIncomplete(CompletedTopic(key))
}
