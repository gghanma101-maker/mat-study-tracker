package com.matstudytracker.data.database

import androidx.room.*
import com.matstudytracker.data.model.StudyRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyRecordDao {
    @Query("SELECT * FROM study_records ORDER BY date DESC")
    fun getAllRecords(): Flow<List<StudyRecord>>

    @Query("SELECT * FROM study_records WHERE date >= :startOfDay AND date < :endOfDay ORDER BY date DESC")
    fun getRecordsForDay(startOfDay: Long, endOfDay: Long): Flow<List<StudyRecord>>

    @Query("SELECT SUM(durationMinutes) FROM study_records")
    fun getTotalMinutes(): Flow<Int?>

    @Query("SELECT SUM(durationMinutes) FROM study_records WHERE date >= :startOfDay AND date < :endOfDay")
    fun getTodayMinutes(startOfDay: Long, endOfDay: Long): Flow<Int?>

    @Query("SELECT SUM(durationMinutes) FROM study_records WHERE subject = :subject")
    fun getMinutesBySubject(subject: String): Flow<Int?>

    @Query("SELECT COUNT(*) FROM study_records")
    fun getRecordCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: StudyRecord)

    @Delete
    suspend fun delete(record: StudyRecord)

    @Update
    suspend fun update(record: StudyRecord)
}
