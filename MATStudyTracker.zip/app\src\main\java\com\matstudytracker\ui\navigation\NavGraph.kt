package com.matstudytracker.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.matstudytracker.data.repository.StudyRepository
import com.matstudytracker.ui.screens.*
import com.matstudytracker.viewmodel.*

@Composable
fun NavGraph(
    navController: NavHostController,
    repository: StudyRepository
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route,
        enterTransition = {
            fadeIn(animationSpec = tween(300)) + slideInHorizontally(
                initialOffsetX = { 100 },
                animationSpec = tween(300)
            )
        },
        exitTransition = {
            fadeOut(animationSpec = tween(300)) + slideOutHorizontally(
                targetOffsetX = { -100 },
                animationSpec = tween(300)
            )
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(300)) + slideInHorizontally(
                initialOffsetX = { -100 },
                animationSpec = tween(300)
            )
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(300)) + slideOutHorizontally(
                targetOffsetX = { 100 },
                animationSpec = tween(300)
            )
        }
    ) {
        composable(Screen.Dashboard.route) {
            val vm: DashboardViewModel = viewModel(
                factory = DashboardViewModel.Factory(repository)
            )
            DashboardScreen(viewModel = vm, navController = navController)
        }

        composable(Screen.Syllabus.route) {
            val vm: SyllabusViewModel = viewModel(
                factory = SyllabusViewModel.Factory(repository)
            )
            SyllabusScreen(viewModel = vm)
        }

        composable(Screen.Planner.route) {
            val vm: PlannerViewModel = viewModel(
                factory = PlannerViewModel.Factory(repository)
            )
            PlannerScreen(viewModel = vm)
        }

        composable(Screen.Records.route) {
            val vm: RecordsViewModel = viewModel(
                factory = RecordsViewModel.Factory(repository)
            )
            RecordsScreen(viewModel = vm)
        }

        composable(Screen.Progress.route) {
            val dashVm: DashboardViewModel = viewModel(
                factory = DashboardViewModel.Factory(repository)
            )
            val syllabusVm: SyllabusViewModel = viewModel(
                factory = SyllabusViewModel.Factory(repository)
            )
            ProgressScreen(
                dashboardViewModel = dashVm,
                syllabusViewModel = syllabusVm,
                repository = repository
            )
        }
    }
}
